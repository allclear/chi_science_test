package work_chi.unit19.student_operator;

import java.util.List;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public interface StudentOperatable {

    /**
     * 根据学生名进行模糊查找
     * @param sname
     * @return 学生列表
     */
    List<Student> selectBySnameLike(String sname);

    /**
     * 根据学号进行排序（降序）
     * @return 学生列表
     */
    List<Student> selectOrderBySno();

    /**
     * 根据学生名模糊查找并排序（升序），然后分页获取第二页数据的操作（每页显示2条）
     * @param sname 学生名
     * @param currPage 当前页
     * @param pageSize 每页显示的数量
     * @return
     */
    List<Student> selectBySnameLikeOrderLimit(String sname, int currPage, int pageSize);
}
