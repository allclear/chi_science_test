package work_chi.unit19.student_operator;

import work_chi.unit18.JDBCUtil;
import work_chi.unit19.JdbcUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public class StudentOperator implements StudentOperatable {

    @Override
    public List<Student> selectBySnameLike(String sname) {
        Connection connection = JdbcUtil.getConnection();
        PreparedStatement preparedStatement = null;
        List<Student> list = new ArrayList<>();
        try {
            String sql = new String("select * from student where sname like ?");
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1,"%"+sname+"%");
            System.out.println(preparedStatement.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Student stu = new Student();
                stu.setSno(resultSet.getString("sno"));
                stu.setSsex(resultSet.getString("ssex"));
                stu.setSage(resultSet.getInt("sage"));
                stu.setSname(resultSet.getString("sname"));
                stu.setSdept(resultSet.getString("sdept"));
                list.add(stu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
        return list;
    }

    @Override
    public List<Student> selectOrderBySno() {
        Connection connection = JDBCUtil.getInstance().getConnection();
        Statement statement = null;
        List<Student> list = new ArrayList<>();
        try {
            statement = connection.createStatement();
            StringBuilder sql = new StringBuilder("select * from student order by sno desc");
            ResultSet rs = statement.executeQuery(sql.toString());
            while (rs.next()) {
                Student s = new Student();
                s.setSno(rs.getString("sno"));
                s.setSsex(rs.getString("ssex"));
                s.setSage(rs.getInt("sage"));
                s.setSname(rs.getString("sname"));
                s.setSdept(rs.getString("sdept"));
                list.add(s);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeResource(statement);
            JdbcUtil.closeResource(connection);
        }
        return list;
    }

    @Override
    public List<Student> selectBySnameLikeOrderLimit(String sname, int currPage, int pageSize) {
        Connection connection = JdbcUtil.getConnection();
        PreparedStatement preparedStatement = null;
        List<Student> list = new ArrayList<>();
        try {
            String sql = new String("select * from student where sname like ? order by sname asc limit ?,?");
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1,"%"+sname+"%");
            preparedStatement.setObject(2,(currPage-1)*pageSize);
            preparedStatement.setObject(3,pageSize);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                Student stu = new Student();
                stu.setSno(resultSet.getString("sno"));
                stu.setSsex(resultSet.getString("ssex"));
                stu.setSage(resultSet.getInt("sage"));
                stu.setSname(resultSet.getString("sname"));
                stu.setSdept(resultSet.getString("sdept"));
                list.add(stu);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
        return list;
    }
}
