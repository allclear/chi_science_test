package work_chi.unit19.student_operator;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public class StudentMain {
    public static void main(String[] args) {
        StudentOperator so = new StudentOperator();
        //so.selectBySnameLike("王").forEach(s-> System.out.println(s));
        //so.selectOrderBySno().forEach(s-> System.out.println(s));
        so.selectBySnameLikeOrderLimit("王",2,2).forEach(s-> System.out.println(s));
    }
}
