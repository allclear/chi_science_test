package work_chi.unit19.transaction;

import work_chi.unit19.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public class Main {

    /**
     * 创建雇员的同时创建其工资
     * 出错则回滚
     */
    public void createEmployee(Employee employee,Integer money){
        Connection connection = JdbcUtil.getConnection();
        PreparedStatement preparedStatement = null;
        try {
            connection.setAutoCommit(false);

            String sql = new String("insert into employee values(?,?)");
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1,employee.getEno());
            preparedStatement.setObject(2,employee.getEname());
            preparedStatement.execute();

            String sql2 = new String("insert into salary values(?,?,?)");
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.setObject(1,null);
            preparedStatement.setObject(2,employee.getEno());
            preparedStatement.setObject(3,money);
            preparedStatement.execute();

            connection.commit();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.closeResource(preparedStatement);
            JdbcUtil.closeResource(connection);
        }
    }

}
