package work_chi.unit19.transaction;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public class Salary {
    private String eno;
    private Integer money;

    public Salary(){}

    public Salary(String eno, Integer money) {
        this.eno = eno;
        this.money = money;
    }

    public String getEno() {
        return eno;
    }

    public void setEno(String eno) {
        this.eno = eno;
    }

    public Integer getMoney() {
        return money;
    }

    public void setMoney(Integer money) {
        this.money = money;
    }

    @Override
    public String toString() {
        return "Salary{" +
                "eno='" + eno + '\'' +
                ", money=" + money +
                '}';
    }
}
