package work_chi.unit19.transaction;

/**
 * @author WXJ
 * @version 1.0
 * @date 2019/8/6
 */
public class Employee {
    private String eno;
    private String ename;

    public Employee() { }

    public Employee(String eno, String ename) {
        this.eno = eno;
        this.ename = ename;
    }

    public String getEno() {
        return eno;
    }

    public void setEno(String eno) {
        this.eno = eno;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "eno='" + eno + '\'' +
                ", ename='" + ename + '\'' +
                '}';
    }
}
